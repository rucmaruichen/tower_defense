﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "waypoint.h"
#include "enemy.h"
#include "bullet.h"
#include "audioplayer.h"
#include "plistreader.h"
#include <QPainter>
#include <QMouseEvent>
#include <QtGlobal>
#include <QMessageBox>
#include <QTimer>
#include <QXmlStreamReader>
#include <QtDebug>
#include <QMediaPlayer>
#include <mynewwindow.h>
#include "mybutton.h"
#include <QKeyEvent>
static const int TowerCost = 300;
QMediaPlayer *player=new QMediaPlayer;
int stop=0;
int tag=1;
MainWindow::MainWindow(QWidget *parent)
	: QMainWindow(parent)
	, ui(new Ui::MainWindow)
	, m_waves(0)
    , m_playerHp(6)
    , m_playrGold(2600)
	, m_gameEnded(false)
	, m_gameWin(false)
{
    x=20; y=20;
    ui->setupUi(this);
    setFixedSize(660,600);
    this->setWindowTitle("Tower Defense");
	preLoadWavesInfo();
	loadTowerPositions();
	addWayPoints();

    player->setMedia(QUrl("qrc:/music/BGM.mp3"));
    player->setVolume(20);
    player->play();
	m_audioPlayer = new AudioPlayer(this);
	m_audioPlayer->startBGM();

	QTimer *timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(updateMap()));
    timer->start(10);
    QMovie *movie=new QMovie(":/image/2.gif");
    ui->label->setMovie(movie);
    movie->start();
    QMovie *hero=new QMovie(":/image/hero.gif");
    ui->label_2->setMovie(hero);
    ui->label_2->move(20,20);
    hero->start();
    QTimer::singleShot(100, this, SLOT(gameStart()));
    mybutton *btn=new mybutton(":/image/snack.png");
    btn->setParent(this);
    btn->move(0,50);
    mynewwindow *scene=new mynewwindow;
    connect(btn,&QPushButton::clicked,this,[=](){
        player->stop();
        QMediaPlayer *player2=new QMediaPlayer;
        player2->setMedia(QUrl("qrc:/music/Unravel.mp3"));
        player2->setVolume(20);
        player2->play();
        btn->zoomdown();
        btn->zoomup();
        QTimer::singleShot(500,this,[=](){
            this->hide();
            scene->show();
        });
    });
    connect(scene,&mynewwindow::chooseback,this,[=](){
            scene->hide();
            this->show();
    });
    return;

}
void MainWindow::settowervoice()
{
    QMediaPlayer *playern=new QMediaPlayer;
    playern->setMedia(QUrl("qrc:/music/BGM.mp3"));
    playern->setVolume(20);
    playern->play();
}
MainWindow::~MainWindow()
{
	delete ui;
}

void MainWindow::loadTowerPositions()
{
	QFile file(":/config/TowersPosition.plist");
	if (!file.open(QFile::ReadOnly | QFile::Text))
	{
		QMessageBox::warning(this, "TowerDefense", "Cannot Open TowersPosition.plist");
		return;
	}

	PListReader reader;
	reader.read(&file);

	QList<QVariant> array = reader.data();
	foreach (QVariant dict, array)
	{
		QMap<QString, QVariant> point = dict.toMap();
		int x = point.value("x").toInt();
		int y = point.value("y").toInt();
		m_towerPositionsList.push_back(QPoint(x, y));
	}

	file.close();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    if (m_gameEnded || m_gameWin)                                    //游戏结束时选择
    {
        if(stop==1)
        {
            if(tag==0)
            {
            QPixmap end(":/image/lose.jpg");
            QPainter painter(this);
            painter.drawPixmap(0,0,this->width(),this->height(),end);
            return;
            }
            QPixmap end(":/image/win.jpg");
            QPainter painter(this);
            painter.drawPixmap(0,0,this->width(),this->height(),end);
            return;
        }
        stop=1;
        player->stop();
        ui->label->hide();
        if(m_gameEnded)
            tag=0;
        if(tag==0)
        {
        QMediaPlayer *playerl=new QMediaPlayer;
        playerl->setMedia(QUrl("qrc:/music/lose.mp3"));
        playerl->setVolume(20);
        playerl->play();
        return;
        }

        QMediaPlayer *playerw=new QMediaPlayer;
        playerw->setMedia(QUrl("qrc:/music/win.mp3"));
        playerw->setVolume(20);
        playerw->play();
		return;
	}

    QPixmap cachePix(":/image/Bg.jpg");
	QPainter cachePainter(&cachePix);

	foreach (const TowerPosition &towerPos, m_towerPositionsList)
		towerPos.draw(&cachePainter);

	foreach (const Tower *tower, m_towersList)
		tower->draw(&cachePainter);

//	foreach (const WayPoint *wayPoint, m_wayPointsList)             初期调整路线需要，可加可不加
//		wayPoint->draw(&cachePainter);

	foreach (const Enemy *enemy, m_enemyList)
		enemy->draw(&cachePainter);

	foreach (const Bullet *bullet, m_bulletList)
		bullet->draw(&cachePainter);

	drawWave(&cachePainter);
	drawHP(&cachePainter);
	drawPlayerGold(&cachePainter);

	QPainter painter(this);
    painter.drawPixmap(0, 0, cachePix);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
	QPoint pressPos = event->pos();
	auto it = m_towerPositionsList.begin();
	while (it != m_towerPositionsList.end())
	{
		if (canBuyTower() && it->containPoint(pressPos) && !it->hasTower())
		{
//			m_audioPlayer->playSound(TowerPlaceSound);
			m_playrGold -= TowerCost;
			it->setHasTower();
//            settowervoice();
			Tower *tower = new Tower(it->centerPos(), this);
			m_towersList.push_back(tower);
			update();
			break;
		}
        if (canBuyTower() && it->containPoint(pressPos) && it->hasTower())
        {
            m_playrGold -= 2*TowerCost;
            Tower *tower = new Tower(it->centerPos(), this);
            tower->m_attackRange=400;
            tower->m_damage=20;
            tower->m_sprite=QPixmap(":/image/lasertower.png");
            m_towersList.push_back(tower);
            update();
              break;
        }
		++it;
	}
}

bool MainWindow::canBuyTower() const
{
	if (m_playrGold >= TowerCost)
		return true;
	return false;
}

void MainWindow::drawWave(QPainter *painter)
{
	painter->setPen(QPen(Qt::red));
	painter->drawText(QRect(400, 5, 100, 25), QString("WAVE : %1").arg(m_waves + 1));
}

void MainWindow::drawHP(QPainter *painter)
{
	painter->setPen(QPen(Qt::red));
	painter->drawText(QRect(30, 5, 100, 25), QString("HP : %1").arg(m_playerHp));
}

void MainWindow::drawPlayerGold(QPainter *painter)
{
	painter->setPen(QPen(Qt::red));
	painter->drawText(QRect(200, 5, 200, 25), QString("GOLD : %1").arg(m_playrGold));
}

void MainWindow::doGameOver()
{
	if (!m_gameEnded)
	{
		m_gameEnded = true;
		// 此处应该切换场景到结束场景
        return;
	}
}

void MainWindow::awardGold(int gold)
{
	m_playrGold += gold;
	update();
}

AudioPlayer *MainWindow::audioPlayer() const
{
	return m_audioPlayer;
}

void MainWindow::addWayPoints()                               //怪物移动路线
{
    WayPoint *wayPoint8 = new WayPoint(QPoint(400, 450));
    m_wayPointsList.push_back(wayPoint8);

    WayPoint *wayPoint7 = new WayPoint(QPoint(600, 450));
    m_wayPointsList.push_back(wayPoint7);
    wayPoint7->setNextWayPoint(wayPoint8);

    WayPoint *wayPoint6 = new WayPoint(QPoint(600, 100));
    m_wayPointsList.push_back(wayPoint6);
    wayPoint6->setNextWayPoint(wayPoint7);

    WayPoint *wayPoint5 = new WayPoint(QPoint(125, 100));
    m_wayPointsList.push_back(wayPoint5);
    wayPoint5->setNextWayPoint(wayPoint6);

    WayPoint *wayPoint4 = new WayPoint(QPoint(125, 195));
    m_wayPointsList.push_back(wayPoint4);
    wayPoint4->setNextWayPoint(wayPoint5);

    WayPoint *wayPoint3 = new WayPoint(QPoint(300, 195));
    m_wayPointsList.push_back(wayPoint3);
    wayPoint3->setNextWayPoint(wayPoint4);

    WayPoint *wayPoint2 = new WayPoint(QPoint(300, 550));                //第二个点
    m_wayPointsList.push_back(wayPoint2);
    wayPoint2->setNextWayPoint(wayPoint3);

    WayPoint *wayPoint1 = new WayPoint(QPoint(60, 550));                 //第一个点
    m_wayPointsList.push_back(wayPoint1);
    wayPoint1->setNextWayPoint(wayPoint2);
}

void MainWindow::getHpDamage(int damage)
{
	m_audioPlayer->playSound(LifeLoseSound);
	m_playerHp -= damage;
	if (m_playerHp <= 0)
		doGameOver();
}

void MainWindow::removedEnemy(Enemy *enemy)
{
	Q_ASSERT(enemy);

	m_enemyList.removeOne(enemy);
	delete enemy;

	if (m_enemyList.empty())
	{
		++m_waves;
		if (!loadWave())
		{
			m_gameWin = true;
			// 游戏胜利转到游戏胜利场景
            return;
		}
	}
}
void MainWindow::removedTower(Tower *tower)
{
    Q_ASSERT(tower);
    m_towersList.removeOne(tower);
    delete tower;
}
void MainWindow::removedBullet(Bullet *bullet)
{
	Q_ASSERT(bullet);
	m_bulletList.removeOne(bullet);
	delete bullet;
}

void MainWindow::addBullet(Bullet *bullet)
{
	Q_ASSERT(bullet);

	m_bulletList.push_back(bullet);
}

void MainWindow::updateMap()
{
	foreach (Enemy *enemy, m_enemyList)
		enemy->move();
	foreach (Tower *tower, m_towersList)
		tower->checkEnemyInRange();
	update();
}

void MainWindow::preLoadWavesInfo()
{
	QFile file(":/config/Waves.plist");
	if (!file.open(QFile::ReadOnly | QFile::Text))
	{
		QMessageBox::warning(this, "TowerDefense", "Cannot Open TowersPosition.plist");
		return;
	}

	PListReader reader;
	reader.read(&file);

	// 获取波数信息
	m_wavesInfo = reader.data();
	file.close();
}

bool MainWindow::loadWave()
{
	if (m_waves >= m_wavesInfo.size())
		return false;

	WayPoint *startWayPoint = m_wayPointsList.back();
	QList<QVariant> curWavesInfo = m_wavesInfo[m_waves].toList();

    for (int i = 0; i < curWavesInfo.size(); i++)
	{
		QMap<QString, QVariant> dict = curWavesInfo[i].toMap();
		int spawnTime = dict.value("spawnTime").toInt();

        Enemy *enemy = new Enemy(startWayPoint, this,QPixmap(":/image/enemy.png"));
        Enemy *enemy2= new Enemy(startWayPoint, this,QPixmap(":/image/enemy2.png"));
        Enemy *enemy3= new Enemy(startWayPoint, this,QPixmap(":/image/enemy3.png"));
        enemy2->m_walkingSpeed=1.2;
        enemy3->m_walkingSpeed=0.6;
        enemy3->m_maxHp=100;
        enemy3->m_currentHp=100;
		m_enemyList.push_back(enemy);
        m_enemyList.push_back(enemy2);
        m_enemyList.push_back(enemy3);
		QTimer::singleShot(spawnTime, enemy, SLOT(doActivate()));
        QTimer::singleShot(spawnTime, enemy2, SLOT(doActivate()));
        QTimer::singleShot(spawnTime, enemy3, SLOT(doActivate()));
	}

	return true;
}

QList<Enemy *> MainWindow::enemyList() const
{
	return m_enemyList;
}

void MainWindow::gameStart()
{
	loadWave();
}
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch(event->key()){
    case Qt::Key_W:
        y-=5;
        break;
    case Qt::Key_S:
        y+=5;
        break;
    case Qt::Key_D:
        x+=5;
        break;
    case Qt::Key_A:
        x-=5;
        break;
    default:
        break;
    }
    ui->label_2->move(x,y);
}
