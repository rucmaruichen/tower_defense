﻿#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QMainWindow>
#include <QPushButton>
class mybutton : public QPushButton
{
    Q_OBJECT
public:
    mybutton(QString pix);
    void zoomdown();
    void zoomup();
signals:

};

#endif // MYBUTTON_H
