﻿#ifndef MYNEWWINDOW_H
#define MYNEWWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include "tower.h"
#include <QList>
#include <QTimer>
#include <QWidget>
#include <QKeyEvent>
#include <QRectF>
class mynewwindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit mynewwindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void set_tower();
    void addmyobject();
    void updatescreen();
    void keyPressEvent(QKeyEvent *);

private:
    void addTopRectF();
    void addDownRectF();
    void addLeftRectF();
    void addRightRectF();
    void deleteLastRectF();
    bool snakeStrike();
    enum Move{Left,Right,Up,Down};
protected slots:
    void timeOut();
    void rewardTimeOut();

private:

    QList<QRectF> snake;//贪吃蛇本体
    int snakeNodeWidth = 10;
    int snakeNodeHeight = 10;
    QTimer *timer;
    QTimer *rewardTimer;
    int time = 100;
    int moveFlage = Up;
    bool gameOver = false;
    bool gameStart = false;
    QList<QRectF> rewardNode;//奖励节点

protected slots:



signals:
    void chooseback();

};

#endif // MYNEWWINDOW_H
